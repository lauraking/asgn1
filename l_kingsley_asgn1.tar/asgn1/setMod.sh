make
sudo rmmod asgn1
sudo insmod ./asgn1.ko
sudo chown pi:pi /dev/asgn1
