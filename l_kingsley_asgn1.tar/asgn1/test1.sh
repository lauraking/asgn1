#!/bin/bash
cat input.in > /dev/asgn1
cat /dev/asgn1
